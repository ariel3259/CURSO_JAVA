package com.ariel.CreateExercises.Exercise_One.interfaces;

public interface StrategyMetodoDePago {
    void pagar();
    double reembolsar();
    double getFondo();
}
