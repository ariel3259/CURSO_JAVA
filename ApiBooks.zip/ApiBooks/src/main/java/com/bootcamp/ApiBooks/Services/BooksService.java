package com.bootcamp.ApiBooks.Services;

import com.bootcamp.ApiBooks.Models.Books;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BooksService {

    List<Books> books = List.of(new Books[]{
            new Books(1, "libro generico 1", "descripcion de libro generico 1", null),
            new Books(2, "generic book 2", "generic book 2's description", null),
            new Books(3, "generic book 3", "generic book 3 description", null)
    });

   public List<Books> getBooks(){
       return books;
   }

   public String saveBook(Books book){
       book.setId(books.size() +1);
       books.add(book);
       return "Book saved";
   }

   public Optional<Books> getBook(int id){
       return Optional.ofNullable(books.get(id - 1));
   }
}
