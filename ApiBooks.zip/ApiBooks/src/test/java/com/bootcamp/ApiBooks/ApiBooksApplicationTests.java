package com.bootcamp.ApiBooks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiBooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
